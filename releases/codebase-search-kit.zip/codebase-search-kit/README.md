# codebase-search kit

Makes any coding agent search a codebase fast and methodically, the way Claude Code does: glob to locate files, ripgrep to find text, ranged reads to inspect, iterative narrowing, and a playbook for hard searches.

It works by giving the agent (1) a short always-on rule set, (2) a longer playbook it reads for hard searches, and (3) a fast helper script. It does not make the underlying model smarter; it makes the agent use search tools well.

## What is inside

```
codebase-search-kit/
├── README.md                     <- this file
├── install.sh                    <- one-command installer for many agents
├── core/
│   ├── RULES.md                  <- compact always-on rules (~50 lines)
│   ├── PLAYBOOK.md               <- full playbook: hard searches, speed tuning
│   └── search.sh                 <- fast helper script (ripgrep, with fallbacks)
└── skill/
    └── codebase-search/          <- ready-to-use Claude skill folder
        ├── SKILL.md
        └── scripts/search.sh
```

## 1. Requirements

| Need | Why | Install |
| --- | --- | --- |
| **ripgrep (`rg`)** | the fast search engine; strongly recommended | macOS `brew install ripgrep` / Ubuntu `sudo apt install ripgrep` / Windows `winget install BurntSushi.ripgrep.MSVC` / any `cargo install ripgrep` |
| **bash** | runs `install.sh` and `search.sh` | built in on macOS/Linux; on Windows use **Git Bash** or **WSL** |
| git | history searches (`hist`) | usually already installed |
| ast-grep (optional) | structural/AST searches (`ast` command) | `npm i -g @ast-grep/cli` or `brew install ast-grep` |

Without `rg` everything still works through `git grep`/`grep`, but it is much slower.

## 2. Quick install (recommended)

```bash
unzip codebase-search-kit.zip
cd codebase-search-kit
chmod +x install.sh
./install.sh <agent> /path/to/your/project
```

Pick `<agent>` from:

| Agent | Command | What it writes |
| --- | --- | --- |
| OpenAI Codex (and anything reading AGENTS.md) | `./install.sh codex .` | `AGENTS.md` |
| Claude Code (rules) | `./install.sh claude .` | `CLAUDE.md` |
| Claude Code (full skill) | `./install.sh claude-skill .` | `.claude/skills/codebase-search/` |
| Gemini CLI | `./install.sh gemini .` | `GEMINI.md` |
| Cursor | `./install.sh cursor .` | `.cursor/rules/codebase-search.mdc` |
| GitHub Copilot | `./install.sh copilot .` | `.github/copilot-instructions.md` |
| Windsurf | `./install.sh windsurf .` | `.windsurf/rules/codebase-search.md` |
| Cline / Roo | `./install.sh cline .` | `.clinerules` |
| Aider | `./install.sh aider .` | `CONVENTIONS.md` (start with `aider --read CONVENTIONS.md`) |
| Everything above | `./install.sh all .` | all of the rule files |

Every agent install also copies the helper tools to `<project>/.codebase-search/` (`search.sh` and `PLAYBOOK.md`), which the rules point to.

Notes:
- The rules are appended inside `<!-- codebase-search:start -->` / `<!-- codebase-search:end -->` markers, so existing content in your `AGENTS.md`/`CLAUDE.md` is kept. Re-running skips if already installed; add `--force` to refresh.
- Commit the generated files to git so the whole team gets the same behavior.

## 3. Manual install (if you cannot run the script)

1. Copy `core/search.sh` and `core/PLAYBOOK.md` into your project at `.codebase-search/`, then `chmod +x .codebase-search/search.sh`.
2. Paste the contents of `core/RULES.md` into your agent's rules file:

| Agent | Rules location |
| --- | --- |
| Codex, many CLI agents | `AGENTS.md` in the repo root |
| Claude Code | `CLAUDE.md` in the repo root, or install the skill folder |
| Gemini CLI | `GEMINI.md` |
| Cursor | `.cursor/rules/codebase-search.mdc` with front matter `alwaysApply: true` |
| Copilot | `.github/copilot-instructions.md` |
| Windsurf | `.windsurf/rules/` (set the rule to always on) |
| Cline / Roo | `.clinerules` |
| Aider | `CONVENTIONS.md`, loaded with `--read` |
| Continue, Zed, others | their "rules" / "system prompt" / "custom instructions" setting |

3. Tool/rule file formats change between releases. If a location above has moved, paste `RULES.md` into whatever the agent calls "project rules" or "custom instructions".

### Claude Code / Claude skills
Copy the folder `skill/codebase-search` to:
- `<project>/.claude/skills/codebase-search/` (this project only), or
- `~/.claude/skills/codebase-search/` (all projects).

In Claude.ai, upload `skill/codebase-search` as a custom skill if your plan supports skills.

## 4. Using the helper script

```bash
.codebase-search/search.sh files   "auth"                # find files by name
.codebase-search/search.sh text    "createUser" src      # line-numbered search
.codebase-search/search.sh def     UserService           # likely definitions
.codebase-search/search.sh refs    UserService           # whole-word usages
.codebase-search/search.sh ctx      "retry|backoff"      # hits with context
.codebase-search/search.sh count   "TODO"                # hits per file
.codebase-search/search.sh slice   src/a.ts 40 90        # numbered line range
.codebase-search/search.sh layout                        # files per directory
.codebase-search/search.sh both    "fetch(" "catch"      # files containing both
.codebase-search/search.sh missing "fetch(" "catch"      # files with A but not B
.codebase-search/search.sh ast      'console.log($$$)' ts   # needs ast-grep
.codebase-search/search.sh hist    "OLD_FLAG"            # who added/removed text
```

Tuning (environment variables): `SEARCH_MAX_LINES` (default 200), `SEARCH_MAX_PER_FILE` (30), `SEARCH_MAX_FILESIZE` (2M).

Optional global ripgrep defaults: create `~/.ripgreprc` with the block shown in `core/PLAYBOOK.md` ("Recommended ripgrep defaults") and set `export RIPGREP_CONFIG_PATH=~/.ripgreprc`.

## 5. Quick test (do this once per agent)

Give the agent these three tasks on your own repo and check that it searches in small steps instead of reading whole files:

1. Simple: "Where is `<some function>` defined and who calls it?"
2. Multi-hop: "Trace what happens from the `<route or button>` to the database write."
3. Hard: "List every place that calls `<API>` without error handling."

Good signs: it uses `rg -l` / `rg -n` / ranged reads, runs several searches at once, cites `path:line`, and says what it could not verify. If it ignores the rules, make sure the rules file is actually loaded (many agents need a new session after you add rules) and, for Cursor, that the rule is set to Always.

## 6. Troubleshooting

| Problem | Fix |
| --- | --- |
| `rg: command not found` | install ripgrep (section 1); the script falls back to `grep` but slower |
| Agent does not follow the rules | start a fresh session/chat; confirm the file is in the repo root; keep rules enabled in the agent's settings |
| `Permission denied` on `search.sh` | `chmod +x .codebase-search/search.sh` |
| Windows: script will not run | use Git Bash or WSL, or paste the `rg` commands from `RULES.md` directly |
| Too many results | pass a directory/glob, e.g. `search.sh text "term" src "*.ts"`, or lower `SEARCH_MAX_LINES` |
| Misses files you expect | they may be git-ignored; try `rg --no-ignore --hidden "term"` once, deliberately |
| `ast` says not installed | `npm i -g @ast-grep/cli` (plain `sg` on Linux is a different tool and is ignored) |

## 7. Updating and uninstalling

- Update: unzip the new kit and run `./install.sh <agent> . --force`.
- Uninstall: delete `<project>/.codebase-search/`, and remove the text between the `codebase-search:start` and `codebase-search:end` markers in your rules files (or delete the Cursor/Windsurf rule files and the `.claude/skills/codebase-search/` folder).

## 8. Honest limits

- This improves how an agent searches. It does not change the quality of the model behind it, so weaker models will follow the playbook less reliably.
- Quality depends on the agent having shell access or real grep/glob/read tools.
- For purely semantic questions on very large codebases (no keywords to match), combine this with a code-search MCP server or an embedding index.
- Rule-file locations and formats are maintained by each tool and may change; when in doubt, use your agent's documentation for "project rules".
